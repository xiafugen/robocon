# 机械狗遥控器映射包（HT-10A → Robocon_Dog）

给「HOTRC HT-10A 十通道遥控器 + 宇树电机的四足狗」用的一套**标准按键/摇杆映射**：
4 个摇杆通道 + 4 个拨杆开关 → 前进/后退、左右拐、横移、跳跃、站立/趴下、急停。

参照了**宇树 Go2/Go1 官方手柄**、**MIT Cheetah-Software 开源 SBUS 映射**、**D1 商用轮足遥控文档**的惯例，
并核对了本地 `10通SBUS协议.pdf`、`HT-10A说明书`、`遥控器代码逐行深度解析.docx` 的实际通道定义。

---

## 30 秒看懂映射

```
        左手                                       右手
   ┌──────────────┐                          ┌──────────────┐
   │  CH4 左右     │  左移 / 右移（可选）      │  CH2 上下     │  前进 / 后退
   │  CH3 上下     │  机身升高 / 降低          │  CH1 左右     │  左转 / 右转
   │ (油门杆不回中)│                          │ (两个轴都回中)│
   └──────────────┘                          └──────────────┘

   SWA(CH5) 模式：上=小跑   中=站立   下=阻尼趴下
   SWB(CH6) 速度：上=100%   中=65%    下=35%
   SWC(CH7) 跳跃：上=跳一次（上升沿）
   SWD(CH8) 急停：上=使能            其它=急停
```

> **为什么驾驶放右手**：Mode 2 的 CH3 是油门杆，通常**松手不回中**；CH1/CH2/CH4 才自动回中。
> 把前进/后退/左右拐都放在右摇杆上，**松手即停**，最安全。
> 想用宇树原版布局（左摇杆前后），把 `RC_CH_VX` 改 3、`RC_CH_HEIGHT` 改 2 ——
> **前提是确认 CH3 会自动回中**，否则前进会落在不回中的油门杆上，松手不会停。

**完整规格（含依据、参数、校准步骤）见 [docs/01_遥控器通道与按键映射标准.md](docs/01_遥控器通道与按键映射标准.md)。**

---

## 目录结构

```
Robocon_xiafugen/
├─ README.md                          ← 本文件
├─ include/
│  ├─ rc_map_config.h                 ← ★ 唯一需要按实物修改的文件（通道/段数/阈值/限幅）
│  └─ rc_map.h                        ← 接口：输入 rc_input_t → 输出 rc_command_t
├─ src/
│  └─ rc_map.c                        ← 映射实现（纯 C99，无 HAL，可直接进 STM32）
├─ examples/
│  ├─ rc_map_glue_robocon_dog.h       ← 胶水声明（C++ 调用必须 include！）
│  └─ rc_map_glue_robocon_dog.c       ← 接到 Robocon_Dog 的胶水 + 1ms 任务示例
├─ tests/
│  └─ test_rc_map.c                   ← 主机端单元测试（14 组 / 74 项断言）
└─ docs/
   ├─ 01_遥控器通道与按键映射标准.md   ← 完整映射标准 + 依据 + 校准流程
   ├─ 遥控器映射表.csv
   └─ 遥控器映射表.xlsx                ← 可打印/发给队友（5 个工作表）
```

---

## 三步接入（Robocon_Dog）

### 1) 拷文件

把 `include/`、`src/`、`examples/rc_map_glue_robocon_dog.c/.h` 加入工程
（例如放到 `Robocon_Dog/User_File/App/`，Keil 里加进 Source Group）。

### 2) 在 1ms 任务里调用

```c
#include "rc_map.h"
#include "rc_map_glue_robocon_dog.h"   /* C++ 文件里必须 include 这个 .h */
#include "bsp_sbus.h"                  /* SBUS_Handle / SBUS_IsOnline */

static rc_command_t g_dog_cmd;

void Task1ms_Callback(void)
{
    SBUS_Handle();                 // 解析最新 SBUS 帧（全工程只调一次）
    rc_map_task_1ms(&g_dog_cmd);   // 遥控 → 语义指令（胶水内的 SBUS_Handle 请注释掉）
    dog_fsm_task(&g_dog_cmd);      // 待写：你的状态机/步态
    motor_task();                  // 按工程当前实现保留
}
```

> - `SBUS_Handle()` 全工程**只能有一个人调用**（bsp_sbus 不可重入）。
>   要么放 1ms 任务（推荐），要么留在 `main.c` 主循环；另一边删掉。
> - 100Hz 任务用 `rc_map_task_step(0.01f, &cmd)`；1ms 任务用 `rc_map_task_1ms(&cmd)`。
> - 接入前**删掉/注释** `main.c` / `rc_motor.cpp` 里"直接给电机写速度"的旧测试链路，
>   否则同一时刻会有两条链路写 `motor_ys_data[].send`。

### 3) 按你的狗改参数

只需改 `include/rc_map_config.h`：通道分配、开关段数（`*_POS`）、最大速度、
死区、中位/端点实测值。**先跑一遍 docs 第 7 章的实机校准**，尤其是开关是两段还是三段。

---

## 验证

### 主机端单元测试（推荐）

```powershell
# 有任意 C 编译器即可，例如 gcc / zig / clang
gcc -std=c99 -Wall -Wextra -Iinclude src/rc_map.c tests/test_rc_map.c -o test_rc_map
.\test_rc_map.exe
# 期望最后一行：==== 结果：74 passed, 0 failed ====
```

也可以验证改配置后测试仍然有效（`#ifndef` 保护，支持 `-D` 覆盖）：

```powershell
gcc -std=c99 -Iinclude -DRC_SW_MODE_POS=2 -DRC_SW_SPEED_POS=2 \
    src/rc_map.c tests/test_rc_map.c -o test_2pos && .\test_2pos.exe
```

### STM32 侧编译检查（本机已装 arm-none-eabi-gcc 时）

```powershell
arm-none-eabi-gcc -std=c99 -Wall -Wextra -Wconversion -Iinclude -c src/rc_map.c -o rc_map.o
```

### 本包已做过的检查

- `arm-none-eabi-gcc -std=c99 -Wall -Wextra -Wconversion` 编译 0 error / 0 warning；
- 主机端单元测试 **14 组 / 74 项断言**全部通过；
- **10 套配置**下测试全绿：默认、VX_MAX 改小、全部通道方向反转、开关全两段、启用 VRA 旋钮、
  宇树式通道布局、关闭 STAND 调高、关闭高度通道、关闭前进通道、中位/端点改 1024/172/1811；

---

## 安全设计（本层已实现，不要绕过）

| 规则 | 行为 |
|---|---|
| 失联 / 坏帧 | 立即 `DAMP` + 速度归零 + `estop=1`（100ms 判定）；恢复后必须把急停开关**拨下再拨上**才重新使能 |
| 使能门控 | 急停开关上 + **三根运动摇杆回中** 才使能，防上电弹射 |
| 急停 fail-safe | 只有 SWD 明确在上档才 ARMED；中位/下档一律 DISARMED |
| 跳跃 | 上升沿触发、1s 冷却、只在"已使能 + 小跑"下生效、上电已拨上不触发 |
| 停车 | 急停 / SWA=DAMP **立即**归零；STAND 才平滑减速 |
| 限幅 | vx/vy 2.5 m/s²、wz 8 rad/s²、height 0.20 m/s；速度上限可调 |

---

## 关于本工作区

本次任务的当前目录 `D:\zhuomian\Robocon_xiafugen` 开始时是空的；
实际遥控器与狗代码在：

- `D:\zhuomian\Robocon_Dog` —— 目标工程（`User_File/BSP/SBUS` 已有 SBUS 驱动 + `rc_chN`）
- `D:\zhuomian\dog` —— 参考/台架工程（`BSP/bsp_sbus.c`、`Device/remote_control`）
- `D:\zhuomian\遥控器代码逐行深度解析.docx` —— 遥控链路逐行分析（通道语义来源）
- `D:\zhuomian\dog\10通SBUS协议.pdf`、`HT-10A说..文版.pdf` —— 协议与遥控器说明书

本包**没有修改**上述任何现有工程文件，是可直接拷入的独立模块。

---

## 参考出处

- 宇树 Go2 官方手册：<https://docs.quadruped.de/projects/go2/html/controller.html>
- 宇树 Go1 官方手册：<https://docs.quadruped.de/projects/go1/html/operation.html>
- unitree_sdk2_python 遥控器解析：<https://github.com/unitreerobotics/unitree_sdk2_python/blob/a035adea/example/wireless_controller/wireless_controller.py>
- MIT Cheetah-Software SBUS/遥控映射：<https://github.com/mit-biomimetics/Cheetah-Software/blob/master/robot/src/rt/rt_rc_interface.cpp>
- D1 轮足遥控说明：<https://d1-development-manual-cn.readthedocs.io/zh-cn/latest/pages/D1_remote_ctrl.html>
- AETR 通道顺序：<https://github.com/TareqAlqutami/DIY-Multiprotocol-TX-Module/blob/master/docs/Channel_Order.md>
