/*
 * rc_map.c — 遥控器(SBUS) → 机械狗运动指令 映射层实现
 *
 * 纯 C99，无 HAL、无动态内存、无浮点库以外的依赖（只用 float 四则运算）。
 * 内部状态全部放在文件作用域的 static 结构里，单实例；
 * 如果以后要多实例（例如两套遥控），把 rc_map_ctx_t 结构体改成传参即可。
 */
#include "rc_map.h"

/* ==========================================================================
 * 配置安全钳位
 * --------------------------------------------------------------------------
 * 浮点配置无法在 C 预处理里做范围检查，这里在编译期把它们钳到合法区间，
 * 避免用户把死区配成 1.0 之类导致除零/NaN。常量表达式在编译期求值，无运行开销。
 * ========================================================================== */
#define RC_SAFE_DEADZONE  (((RC_STICK_DEADZONE) > 0.0f) && ((RC_STICK_DEADZONE) < 0.9f) ? (RC_STICK_DEADZONE) : 0.0f)
#define RC_SAFE_EXPO      (((RC_STICK_EXPO) > 0.0f) ? (((RC_STICK_EXPO) < 1.0f) ? (RC_STICK_EXPO) : 1.0f) : 0.0f)
#define RC_SAFE_ACC(x)    (((x) > 0.0f) ? (x) : 0.0f)
#define RC_SAFE_HMIN      (((RC_HEIGHT_MIN) >= 0.0f) ? (RC_HEIGHT_MIN) : 0.0f)
#define RC_SAFE_HMAX      (((RC_HEIGHT_MAX) > RC_SAFE_HMIN) ? (RC_HEIGHT_MAX) : (RC_SAFE_HMIN))

static const float s_deadzone = RC_SAFE_DEADZONE;
static const float s_expo     = RC_SAFE_EXPO;
static const float s_acc_vx   = RC_SAFE_ACC(RC_ACC_VX);
static const float s_acc_vy   = RC_SAFE_ACC(RC_ACC_VY);
static const float s_acc_wz   = RC_SAFE_ACC(RC_ACC_WZ);
static const float s_acc_h    = RC_SAFE_ACC(RC_ACC_HEIGHT);
static const float s_h_min    = RC_SAFE_HMIN;
static const float s_h_max    = RC_SAFE_HMAX;

/* ==========================================================================
 * 小工具
 * ========================================================================== */
static float rc_clampf(float v, float lo, float hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

static float rc_absf(float v)
{
    return (v < 0.0f) ? -v : v;
}

/* ==========================================================================
 * 内部状态
 * ========================================================================== */
typedef struct
{
    uint8_t initialized;      /* 是否已完成首次初始化（首帧不触发跳跃） */

    int8_t  prev_mode;        /* 上一周期的开关档位，用于回差与边沿检测 */
    int8_t  prev_speed;
    int8_t  prev_jump;
    int8_t  prev_arm;

    uint8_t arm_latched;      /* 使能锁存：开关拨上 + 摇杆回中后才置 1 */
    uint8_t arm_cycle_req;    /* 失联后必须"拨下再拨上"才允许重新使能（飞控 arming 惯例） */
    float   jump_cd_s;        /* 跳跃冷却剩余秒数 */

    float   vx;               /* 加速度限幅后的实际输出 */
    float   vy;
    float   wz;
    float   height;           /* 速率限幅后的高度输出 */
} rc_map_ctx_t;

static rc_map_ctx_t s_ctx;
/* ==========================================================================
 * 开关档位解码（带回差）
 *   返回 +1 = 上档，0 = 中档，-1 = 下档
 * ========================================================================== */
static int8_t rc_sw_decode(uint16_t raw, uint8_t pos_count, int8_t prev)
{
    if (pos_count >= 3)
    {
        /* 三段开关：外侧两档先判，其余归中档；回差防止阈值附近抖动 */
        if ((int32_t)raw > (int32_t)(RC_SW_HIGH_TH + RC_SW_HYST))
        {
            return 1;
        }
        if ((int32_t)raw < (int32_t)(RC_SW_LOW_TH - RC_SW_HYST))
        {
            return -1;
        }
        /* 落在回差区间内：尽量保持上一档，否则判中档 */
        if (prev == 1 && (int32_t)raw > (int32_t)(RC_SW_HIGH_TH - RC_SW_HYST))
        {
            return 1;
        }
        if (prev == -1 && (int32_t)raw < (int32_t)(RC_SW_LOW_TH + RC_SW_HYST))
        {
            return -1;
        }
        return 0;
    }

    /* 两段开关：以原始中位为界，±RC_SW_HYST 回差 */
    if (prev == 1)
    {
        return ((int32_t)raw < (int32_t)(RC_RAW_MID - RC_SW_HYST)) ? -1 : 1;
    }
    return ((int32_t)raw > (int32_t)(RC_RAW_MID + RC_SW_HYST)) ? 1 : -1;
}

/* ==========================================================================
 * 急停/使能开关解码（fail-safe）
 *   与普通开关不同：**只有明确在上档才算 ARMED**，中位、下档、阈值附近
 *   一律 DISARMED。这样即使 SWD 实际是三段开关（文档无法确认段数），
 *   拨到中位也会立即急停，不会出现"中位仍使能"的危险状态。
 *   回差只用于去抖，方向始终偏向"解除使能"。
 * ========================================================================== */
static uint8_t rc_arm_decode(uint16_t raw, int8_t prev)
{
    int32_t hi = (int32_t)RC_SW_HIGH_TH;

    if (prev == 1)
    {
        /* 已使能：低于 (阈值-回差) 才判为脱离上档（去抖） */
        return ((int32_t)raw > (hi - (int32_t)RC_SW_HYST)) ? 1U : 0U;
    }
    /* 未使能：必须明确高于 (阈值+回差) 才算拨到上档 */
    return ((int32_t)raw > (hi + (int32_t)RC_SW_HYST)) ? 1U : 0U;
}

/* ==========================================================================
 * 摇杆归一化：原始值 → [-1, +1]
 *   - 按 RC_RAW_MIN/MID/MAX 分段线性（比固定 1024/1023 更贴近真实舵量）
 *   - 方向 RC_DIR_*
 *   - 中位死区 + 死区外重新拉伸
 *   - 可选 Expo 曲线
 * ========================================================================== */
static float rc_axis_norm(uint16_t raw, int8_t dir)
{
    int32_t delta = (int32_t)raw - (int32_t)RC_RAW_MID;
    float   v;

    /* 原始值死区：摇杆机械中位附近直接归零，避免 992/1024 差异带来的抖动 */
    if ((delta > -(int32_t)RC_RAW_DEADBAND) && (delta < (int32_t)RC_RAW_DEADBAND))
    {
        return 0.0f;
    }

    if (delta >= 0)
    {
        v = (float)delta / (float)(RC_RAW_MAX - RC_RAW_MID);
    }
    else
    {
        v = (float)delta / (float)(RC_RAW_MID - RC_RAW_MIN);
    }
    v = rc_clampf(v, -1.0f, 1.0f);
    v *= (float)dir;

    /* 归一化死区 + 重新拉伸 */
    if (rc_absf(v) < s_deadzone)
    {
        return 0.0f;
    }
    v = (v > 0.0f)
        ? (v - s_deadzone) / (1.0f - s_deadzone)
        : (v + s_deadzone) / (1.0f - s_deadzone);
    v = rc_clampf(v, -1.0f, 1.0f);

    /* Expo（可选）：中位更细腻。s_expo 为 0 时编译器会把这段优化掉 */
    if (s_expo > 0.0f)
    {
        float a = rc_absf(v);
        float curved = (1.0f - s_expo) * a + s_expo * a * a * a;
        v = (v < 0.0f) ? -curved : curved;
    }

    return v;
}

/* 读取指定通道的原始值（通道号从 1 开始；0 或越界返回中位） */
static uint16_t rc_ch_raw(const rc_input_t *in, uint8_t ch)
{
    if ((ch == 0U) || (ch > RC_MAP_CH_NUM))
    {
        return (uint16_t)RC_RAW_MID;
    }
    return in->raw[ch - 1U];
}

/* ==========================================================================
 * 复位
 * ========================================================================== */
void rc_map_init(void)
{
    s_ctx.initialized = 0U;
    s_ctx.prev_mode   = 0;
    s_ctx.prev_speed  = 0;
    s_ctx.prev_jump   = 0;
    s_ctx.prev_arm    = 0;
    s_ctx.arm_latched = 0U;
    s_ctx.arm_cycle_req = 0U;
    s_ctx.jump_cd_s   = 0.0f;
    s_ctx.vx          = 0.0f;
    s_ctx.vy          = 0.0f;
    s_ctx.wz          = 0.0f;
    s_ctx.height      = 0.0f;   /* 0 = 尚未收到有效高度指令 */
}

/* ==========================================================================
 * 主映射
 * ========================================================================== */
int rc_map_update(const rc_input_t *in, float dt, rc_command_t *out, rc_map_debug_t *dbg)
{
    float stick_vx, stick_vy, stick_wz, stick_h;
    float knob01;
    int8_t sw_mode, sw_speed, sw_jump, sw_arm;
    uint8_t link_ok;
    uint8_t estop;
    rc_gait_t gait;
    uint8_t jump_req = 0U;
    float speed_scale;
    float tgt_vx = 0.0f, tgt_vy = 0.0f, tgt_wz = 0.0f;
    float height = 0.0f;

    if ((in == 0) || (out == 0))
    {
        return -1;
    }

    /* dt 保护：异常值按 1ms 处理，避免加速度限制被 dt=0 或超大值破坏 */
    if (!(dt > 0.0f) || (dt > 0.1f))
    {
        dt = 0.001f;
    }

    /* ---------------- 1. 解出 4 个连续量 ---------------- */
    stick_vx = rc_axis_norm(rc_ch_raw(in, RC_CH_VX),  RC_DIR_VX);
    stick_vy = rc_axis_norm(rc_ch_raw(in, RC_CH_VY),  RC_DIR_VY);
    stick_wz = rc_axis_norm(rc_ch_raw(in, RC_CH_YAW), RC_DIR_YAW);
    stick_h  = rc_axis_norm(rc_ch_raw(in, RC_CH_HEIGHT), RC_DIR_HEIGHT);

    knob01 = 0.0f;
#if (RC_CH_SPEED_KNOB > 0)
    {
        float knob = rc_axis_norm(rc_ch_raw(in, RC_CH_SPEED_KNOB), RC_DIR_SPEED_KNOB);
        knob01 = (knob + 1.0f) * 0.5f;   /* -1~+1 → 0~1 */
    }
#else
    knob01 = 1.0f;
#endif

    /* ---------------- 2. 解出 4 个开关档位 ---------------- */
    sw_mode  = rc_sw_decode(rc_ch_raw(in, RC_SW_MODE),  RC_SW_MODE_POS,  s_ctx.prev_mode);
    sw_speed = rc_sw_decode(rc_ch_raw(in, RC_SW_SPEED), RC_SW_SPEED_POS, s_ctx.prev_speed);
    sw_jump  = rc_sw_decode(rc_ch_raw(in, RC_SW_JUMP),  RC_SW_JUMP_POS,  s_ctx.prev_jump);
    /* 急停用 fail-safe 解码：只有明确在上档才是 1，中位/下档一律 0 */
    sw_arm   = (int8_t)rc_arm_decode(rc_ch_raw(in, RC_SW_ARM), s_ctx.prev_arm);

    /* ---------------- 3. 首帧初始化（只记录初值，不产生跳跃边沿） ---------------- */
    if (!s_ctx.initialized)
    {
        s_ctx.prev_mode  = sw_mode;
        s_ctx.prev_speed = sw_speed;
        s_ctx.prev_jump  = sw_jump;
        s_ctx.prev_arm   = sw_arm;
        s_ctx.initialized = 1U;
    }

    /* ---------------- 4. 链路 / 使能判定 ----------------
     * 规则（参考飞控 arming 惯例）：
     *   1) 失联 → 立即解除使能；若急停开关还停在"上"，记一个"需要拨下再拨上"的标志，
     *      这样链路恢复后不会自己突然恢复使能；
     *   2) 急停开关拨下 → 解除使能，同时清掉上面的标志；
     *   3) 开关在上、无失联标志、摇杆回中 → 允许使能。 */
    link_ok = (uint8_t)((in->online != 0U) && (in->valid != 0U));

    if (!link_ok)
    {
        s_ctx.arm_latched = 0U;
        if (sw_arm == 1)
        {
            s_ctx.arm_cycle_req = 1U;   /* 失联时开关还压在上：必须拨下再拨上 */
        }
    }
    else if (sw_arm != 1)
    {
        s_ctx.arm_latched = 0U;
        s_ctx.arm_cycle_req = 0U;       /* 开关已拨下 → 允许下一次拨上时使能 */
    }
    else if (s_ctx.arm_cycle_req != 0U)
    {
        s_ctx.arm_latched = 0U;         /* 等操作手把开关拨下再拨上 */
    }
    else if (!s_ctx.arm_latched)
    {
        /* 要求摇杆回中才允许使能，防止上电时摇杆被压住导致窜出 */
        if ((rc_absf(stick_vx) < RC_ARM_STICK_LIMIT) &&
            (rc_absf(stick_vy) < RC_ARM_STICK_LIMIT) &&
            (rc_absf(stick_wz) < RC_ARM_STICK_LIMIT))
        {
            s_ctx.arm_latched = 1U;
        }
    }

    estop = (uint8_t)((!link_ok) || (s_ctx.arm_latched == 0U));

    /* ---------------- 5. 步态 ---------------- */
    if (estop)
    {
        gait = RC_GAIT_DAMP;
    }
    else if (sw_mode > 0)
    {
        gait = RC_GAIT_TROT;      /* 上 = 小跑 */
    }
    else if (sw_mode == 0)
    {
        gait = RC_GAIT_STAND;     /* 中 = 站立 */
    }
    else
    {
        gait = RC_GAIT_DAMP;      /* 下 = 阻尼趴下（软急停） */
    }

    /* ---------------- 6. 跳跃触发（上升沿 + 互锁 + 冷却） ---------------- */
    if (s_ctx.jump_cd_s > 0.0f)
    {
        s_ctx.jump_cd_s -= dt;
        if (s_ctx.jump_cd_s < 0.0f)
        {
            s_ctx.jump_cd_s = 0.0f;
        }
    }

    if ((estop == 0U) &&
        (gait == RC_GAIT_TROT) &&
        (sw_jump == 1) &&
        (s_ctx.prev_jump != 1) &&
        (s_ctx.jump_cd_s <= 0.0f))
    {
        jump_req = 1U;
        s_ctx.jump_cd_s = (float)RC_JUMP_COOLDOWN_MS / 1000.0f;
    }

    /* ---------------- 7. 速度档位 × 旋钮 ---------------- */
    if (sw_speed > 0)
    {
        speed_scale = RC_SPEED_HIGH;
    }
    else if (sw_speed == 0)
    {
        speed_scale = RC_SPEED_MID;
    }
    else
    {
        speed_scale = RC_SPEED_LOW;
    }

#if (RC_CH_SPEED_KNOB > 0)
    speed_scale *= (RC_KNOB_MIN + (1.0f - RC_KNOB_MIN) * knob01);
#endif
    speed_scale = rc_clampf(speed_scale, 0.0f, RC_SPEED_SCALE_MAX);

    /* ---------------- 8. 计算目标速度 ---------------- */
    if ((estop == 0U) && (gait == RC_GAIT_TROT))
    {
        tgt_vx = stick_vx * RC_VX_MAX * speed_scale;
        tgt_vy = stick_vy * RC_VY_MAX * speed_scale;
        tgt_wz = stick_wz * RC_WZ_MAX * speed_scale;
    }
    /* 其余情况（DAMP / STAND / 未使能）目标速度保持 0 */

    /* 机身高度：非 DAMP 时由高度杆映射；DAMP/急停时输出 0 表示"无效" */
    {
        float tgt_h = 0.0f;
        uint8_t h_valid = 0U;

        if ((RC_CH_HEIGHT != 0) && (estop == 0U) && (gait != RC_GAIT_DAMP) &&
            ((gait == RC_GAIT_TROT) || (RC_HEIGHT_IN_STAND != 0)))
        {
            float h01 = (stick_h + 1.0f) * 0.5f;   /* -1~+1 → 0~1 */
            tgt_h = s_h_min + (s_h_max - s_h_min) * h01;
            h_valid = 1U;
        }

        if (h_valid == 0U)
        {
            height = 0.0f;                          /* 0 = 无效 */
        }
        else
        {
            if (s_ctx.height <= 0.0f)
            {
                s_ctx.height = tgt_h;               /* 首次/复位后直接给目标，避免从 0 爬升 */
            }
            else
            {
                float dh = s_acc_h * dt;
                if (tgt_h > s_ctx.height + dh)      { s_ctx.height += dh; }
                else if (tgt_h < s_ctx.height - dh) { s_ctx.height -= dh; }
                else                                { s_ctx.height = tgt_h; }
            }
            height = s_ctx.height;
        }
    }

    /* ---------------- 9. 速度限幅 ----------------
     * 急停 / SWA=DAMP：立即归零（安全优先，不做平滑）；
     * STAND：斜坡降到 0（软停，避免站立瞬间前冲）；
     * TROT：按加速度限幅跟踪目标。 */
    if ((estop != 0U) || (gait == RC_GAIT_DAMP))
    {
        s_ctx.vx = 0.0f;
        s_ctx.vy = 0.0f;
        s_ctx.wz = 0.0f;
    }
    else
    {
        float dvx = s_acc_vx * dt;
        float dvy = s_acc_vy * dt;
        float dwz = s_acc_wz * dt;

        if (tgt_vx > s_ctx.vx + dvx)      { s_ctx.vx += dvx; }
        else if (tgt_vx < s_ctx.vx - dvx) { s_ctx.vx -= dvx; }
        else                              { s_ctx.vx = tgt_vx; }

        if (tgt_vy > s_ctx.vy + dvy)      { s_ctx.vy += dvy; }
        else if (tgt_vy < s_ctx.vy - dvy) { s_ctx.vy -= dvy; }
        else                              { s_ctx.vy = tgt_vy; }

        if (tgt_wz > s_ctx.wz + dwz)      { s_ctx.wz += dwz; }
        else if (tgt_wz < s_ctx.wz - dwz) { s_ctx.wz -= dwz; }
        else                              { s_ctx.wz = tgt_wz; }
    }

    /* ---------------- 10. 输出 ---------------- */
    out->vx          = s_ctx.vx;
    out->vy          = s_ctx.vy;
    out->wz          = s_ctx.wz;
    out->height      = height;
    out->gait        = gait;
    out->speed_scale = speed_scale;
    out->armed       = s_ctx.arm_latched;
    out->jump        = jump_req;
    out->estop       = estop;
    out->online      = (uint8_t)((in->online != 0U) && (in->valid != 0U));

    if (dbg != 0)
    {
        dbg->stick[0] = stick_vx;
        dbg->stick[1] = stick_vy;
        dbg->stick[2] = stick_wz;
        dbg->stick[3] = stick_h;
        dbg->sw_mode  = sw_mode;
        dbg->sw_speed = sw_speed;
        dbg->sw_jump  = sw_jump;
        dbg->sw_arm   = sw_arm;
        dbg->knob     = knob01;
    }

    /* ---------------- 11. 保存本周期开关状态（供下一周期边沿/回差） ---------------- */
    s_ctx.prev_mode  = sw_mode;
    s_ctx.prev_speed = sw_speed;
    s_ctx.prev_jump  = sw_jump;
    s_ctx.prev_arm   = sw_arm;

    return 0;
}

/* ==========================================================================
 * 调试辅助
 * ========================================================================== */
const char *rc_gait_name(rc_gait_t gait)
{
    switch (gait)
    {
        case RC_GAIT_DAMP:  return "DAMP";
        case RC_GAIT_STAND: return "STAND";
        case RC_GAIT_TROT:  return "TROT";
        default:            return "?";
    }
}
