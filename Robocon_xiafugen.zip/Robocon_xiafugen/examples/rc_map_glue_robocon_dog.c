/*
 * rc_map_glue_robocon_dog.c — 把本映射层接到 Robocon_Dog 工程的示例胶水代码
 * ==========================================================================
 * 用法（二选一）：
 *   A) 把本文件 + rc_map_glue_robocon_dog.h 拷到 Robocon_Dog/User_File/App/ 加入编译；
 *   B) 直接抄 rc_map_fill_from_sbus()/rc_map_task_step() 到你现有 control_task.cpp。
 *
 * 依赖 Robocon_Dog 已有的：
 *   User_File/BSP/SBUS/bsp_sbus.h  → rc_ch1..rc_ch10、sbus_data[25]、
 *                                    SBUS_Handle()、SBUS_IsOnline()
 * 本文件不修改任何现有文件，只新增一个映射任务。
 *
 * 数据流：
 *   UART5 中断 → SBUS_Reveive → (SBUS_Handle) → rc_ch1..rc_ch10
 *              → rc_map_fill_from_sbus() → rc_map_update() → rc_command_t
 *              → 你的步态/状态机（目前工程里还没有，见 TODO）
 */
#include "rc_map_glue_robocon_dog.h"
#include "bsp_sbus.h"   /* rc_ch1..rc_ch10, sbus_data[], SBUS_Handle(), SBUS_IsOnline() */

/* --------------------------------------------------------------------------
 * 把 bsp_sbus 的全局变量打包成 rc_map 的输入结构
 * -------------------------------------------------------------------------- */
void rc_map_fill_from_sbus(rc_input_t *in)
{
    if (in == 0)
    {
        return;
    }

    in->raw[0] = (uint16_t)rc_ch1;
    in->raw[1] = (uint16_t)rc_ch2;
    in->raw[2] = (uint16_t)rc_ch3;
    in->raw[3] = (uint16_t)rc_ch4;
    in->raw[4] = (uint16_t)rc_ch5;
    in->raw[5] = (uint16_t)rc_ch6;
    in->raw[6] = (uint16_t)rc_ch7;
    in->raw[7] = (uint16_t)rc_ch8;
    in->raw[8] = (uint16_t)rc_ch9;
    in->raw[9] = (uint16_t)rc_ch10;

    /* SBUS 状态字节 bit2=LOST, bit3=FAILSAFE：两位都为 0 才是正常帧 */
    in->valid  = (uint8_t)((sbus_data[23] & ((1U << 2) | (1U << 3))) == 0U);
    in->online = SBUS_IsOnline();
}

/* --------------------------------------------------------------------------
 * 映射步进（dt 单位：秒）
 *
 * 注意：SBUS_Handle() 全工程只应调用一次。如果 control_task.cpp / main.c 里
 *       已经调用，就把下面这行注释掉，避免重复解析（bsp_sbus 不是可重入的）。
 * -------------------------------------------------------------------------- */
void rc_map_task_step(float dt, rc_command_t *out_cmd)
{
    static rc_input_t   s_in;
    static rc_command_t s_cmd;
    static rc_map_debug_t s_dbg;
    static uint8_t s_inited = 0U;

    if (out_cmd == 0)
    {
        return;
    }

    if (!s_inited)
    {
        rc_map_init();
        s_inited = 1U;
    }

    /* 1) 解析最新一帧（若已在别处调用，注释掉这一行） */
    SBUS_Handle();

    /* 2) 打包输入 → 3) 映射 */
    rc_map_fill_from_sbus(&s_in);
    rc_map_update(&s_in, dt, &s_cmd, &s_dbg);

    /* 4) 交给上层 */
    *out_cmd = s_cmd;

    /* 调试：可以把 s_dbg / s_cmd 打到串口或 OLED
     * printf("%s vx=%.2f vy=%.2f wz=%.2f h=%.2f arm=%d jump=%d estop=%d\r\n",
     *        rc_gait_name(s_cmd.gait), s_cmd.vx, s_cmd.vy, s_cmd.wz,
     *        s_cmd.height, s_cmd.armed, s_cmd.jump, s_cmd.estop); */
}

/* 1ms 任务便捷封装 */
void rc_map_task_1ms(rc_command_t *out_cmd)
{
    rc_map_task_step(0.001f, out_cmd);
}

/* ==========================================================================
 * TODO（接下来在 Robocon_Dog 里要写的部分，本映射层只负责"遥控→指令"）
 * --------------------------------------------------------------------------
 * 1) 步态/状态机：接收 rc_command_t，决定 12 个关节的目标（DAMP/STAND/TROT/JUMP）；
 * 2) 跳跃时序：rc_command_t.jump 是单周期脉冲，需要你自己锁存并执行
 *    预压→蹬伸→收腿→落地缓冲，期间忽略摇杆速度指令；
 * 3) 机身高度：rc_command_t.height 是目标值（m），用你的腿部 IK/高度环执行；
 * 4) 速度比例：rc_command_t.speed_scale 乘到步频/步长上；
 * 5) 8 个宇树电机的并行发帧（当前工程只验证了 0 号电机）。
 * 6) 注意：main.c 里若仍有"CH1 直写电机"的旧测试链路，接入后必须删掉，
 *    否则同一时刻会有两条链路写 motor_ys_data[].send。
 * ========================================================================== */
