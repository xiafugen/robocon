/*
 * rc_map_glue_robocon_dog.h — 把 rc_map 映射层接到 Robocon_Dog 的胶水声明
 * ==========================================================================
 * 放在 control_task.cpp 里调用时，必须 include 本头文件（C++ 需要 extern "C"，
 * 否则链接阶段找不到 C 函数）。
 *
 * 依赖 Robocon_Dog 已有的：
 *   User_File/BSP/SBUS/bsp_sbus.h  → rc_ch1..rc_ch10、sbus_data[25]、
 *                                    SBUS_Handle()、SBUS_IsOnline()
 */
#ifndef RC_MAP_GLUE_ROBOCON_DOG_H
#define RC_MAP_GLUE_ROBOCON_DOG_H

#include "rc_map.h"

#ifdef __cplusplus
extern "C" {
#endif

/* 把 bsp_sbus 的全局变量打包成 rc_map 的输入结构 */
void rc_map_fill_from_sbus(rc_input_t *in);

/* 带显式 dt 的映射步进（dt 单位：秒）。
 * 放在 1ms 任务里传 0.001f；放在 100Hz 任务里传 0.01f。
 * 内部会调用 SBUS_Handle() 解析最新帧（若你在别处已调用，请把 .c 里那行删掉）。 */
void rc_map_task_step(float dt, rc_command_t *out_cmd);

/* 1ms 任务的便捷封装，等价于 rc_map_task_step(0.001f, out_cmd) */
void rc_map_task_1ms(rc_command_t *out_cmd);

#ifdef __cplusplus
}
#endif

#endif /* RC_MAP_GLUE_ROBOCON_DOG_H */
