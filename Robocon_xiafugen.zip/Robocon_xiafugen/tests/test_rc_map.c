/*
 * test_rc_map.c — rc_map 映射层主机端单元测试（不依赖单片机）
 *
 * 编译运行（任选其一）：
 *   gcc -std=c99 -Wall -Wextra -Iinclude src/rc_map.c tests/test_rc_map.c -o test_rc_map && ./test_rc_map
 *   zig cc -std=c99 -Iinclude src/rc_map.c tests/test_rc_map.c -o test_rc_map
 * Windows PowerShell 下： .\test_rc_map.exe
 *
 * 测试用宏（RC_CH_xxx / RC_DIR_xxx / RC_SW_xxx_POS 等）动态读取配置，因此改
 * rc_map_config.h 的通道分配、开关段数、方向后，本测试仍然有效。
 *
 * 覆盖：
 *   摇杆方向 / 死区 / 加速度限幅 / 开关档位(2段3段) / 急停 fail-safe 解码 /
 *   使能门控 / 失联&坏帧急停 / 失联后拨杆复位 / 跳跃上升沿+冷却+首帧保护 /
 *   三种模式 / DAMP 立即停车 / 高度速率限幅 / 速度档 / 边界值 / 调试输出
 */
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "rc_map.h"

static int g_fail = 0;
static int g_pass = 0;

#define CHECK(cond)                                                         \
    do {                                                                    \
        if (cond) { g_pass++; }                                             \
        else {                                                              \
            g_fail++;                                                       \
            printf("  [FAIL] %s:%d  %s\n", __FILE__, __LINE__, #cond);      \
        }                                                                   \
    } while (0)

#define CHECK_NEAR(a, b, eps)                                               \
    do {                                                                    \
        double va = (double)(a), vb = (double)(b);                          \
        if (fabs(va - vb) <= (double)(eps)) { g_pass++; }                   \
        else {                                                              \
            g_fail++;                                                       \
            printf("  [FAIL] %s:%d  |%.4f - %.4f| > %.4f  (%s)\n",          \
                   __FILE__, __LINE__, va, vb, (double)(eps), #a);          \
        }                                                                   \
    } while (0)

/* 通道号(1-based) → 原始值数组下标 */
#define RAW(ch)  ((ch) - 1)

/* 安全写一个通道的原始值：通道号 0/越界时忽略（用于"该功能不接摇杆"的配置） */
static void set_raw(rc_input_t *in, uint8_t ch, uint16_t val)
{
    if ((ch >= 1U) && (ch <= (uint8_t)RC_MAP_CH_NUM)) {
        in->raw[ch - 1U] = val;
    }
}

/* 通道方向宏 → ±1.0，便于测试在改 RC_DIR_xxx 后仍然成立 */
static float dir_of(int8_t d)
{
    return (d > 0) ? 1.0f : -1.0f;
}

/* 取一个已接的运动通道，用于与具体通道号无关的越权/使能测试 */
static uint8_t any_motion_ch(void)
{
    if (RC_CH_VX != 0) return (uint8_t)RC_CH_VX;
    if (RC_CH_VY != 0) return (uint8_t)RC_CH_VY;
    return (uint8_t)RC_CH_YAW;
}

/* 期望的速度比例：档位 × 旋钮（旋钮在中位时归一化为 0 → 0.5），再限幅 */
static float expect_scale(float level)
{
#if (RC_CH_SPEED_KNOB > 0)
    level *= (RC_KNOB_MIN + (1.0f - RC_KNOB_MIN) * 0.5f);
#endif
    if (level > RC_SPEED_SCALE_MAX) level = RC_SPEED_SCALE_MAX;
    if (level < 0.0f) level = 0.0f;
    return level;
}

/* 构造一帧：所有通道先置中位，再按需要改 */
static rc_input_t make_frame(uint16_t mode_sw, uint16_t speed_sw,
                             uint16_t jump_sw, uint16_t arm_sw)
{
    rc_input_t in;
    int i;

    memset(&in, 0, sizeof(in));
    for (i = 0; i < RC_MAP_CH_NUM; i++) {
        in.raw[i] = (uint16_t)RC_RAW_MID;
    }
    in.valid  = 1;
    in.online = 1;

    set_raw(&in, RC_SW_MODE, mode_sw);
    set_raw(&in, RC_SW_SPEED, speed_sw);
    set_raw(&in, RC_SW_JUMP, jump_sw);
    set_raw(&in, RC_SW_ARM, arm_sw);
    return in;
}

/* 跑 n 次 1ms 更新，返回最后一次命令 */
static rc_command_t run_ms(rc_input_t *in, int n)
{
    rc_command_t out;
    int i;
    memset(&out, 0, sizeof(out));
    for (i = 0; i < n; i++) {
        rc_map_update(in, 0.001f, &out, 0);
    }
    return out;
}

/* 常用组合：已使能 + 小跑档 + 快档 + 跳跃待命 */
static rc_input_t armed_trot_frame(void)
{
    return make_frame((uint16_t)RC_RAW_MAX, (uint16_t)RC_RAW_MAX,
                      (uint16_t)RC_RAW_MIN, (uint16_t)RC_RAW_MAX);
}

static void test_neutral(void)
{
    rc_input_t in = armed_trot_frame();
    rc_command_t out;

    printf("[1] 中位/已使能：应 TROT、速度为 0、armed=1\n");
    rc_map_init();
    out = run_ms(&in, 1000);

    CHECK(out.gait == RC_GAIT_TROT);
    CHECK(out.armed == 1U);
    CHECK(out.estop == 0U);
    CHECK(out.online == 1U);
    CHECK_NEAR(out.vx, 0.0f, 1e-6);
    CHECK_NEAR(out.vy, 0.0f, 1e-6);
    CHECK_NEAR(out.wz, 0.0f, 1e-6);
    CHECK_NEAR(out.speed_scale, expect_scale(RC_SPEED_HIGH), 1e-6);
    CHECK(out.jump == 0U);
}

static void test_forward_backward(void)
{
    rc_input_t in = armed_trot_frame();
    rc_command_t out;
    float vmax = RC_VX_MAX * expect_scale(RC_SPEED_HIGH);
    float dirvx = dir_of(RC_DIR_VX);

    printf("[2] 前进/后退：CH2 满推 = ±RC_VX_MAX×档位（方向随 RC_DIR_VX）\n");
#if (RC_CH_VX == 0)
    printf("  (跳过：RC_CH_VX=0，前进通道未接)\n");
#else
    rc_map_init();
    run_ms(&in, 10);                       /* 先使能 */
    set_raw(&in, RC_CH_VX, (uint16_t)RC_RAW_MAX);
    out = run_ms(&in, 400);
    CHECK_NEAR(out.vx, dirvx * vmax, 1e-3);

    in = armed_trot_frame();
    rc_map_init();
    run_ms(&in, 10);
    set_raw(&in, RC_CH_VX, (uint16_t)RC_RAW_MIN);
    out = run_ms(&in, 600);
    CHECK_NEAR(out.vx, -dirvx * vmax, 1e-3);
#endif
}

static void test_slew_limit(void)
{
    rc_input_t in = armed_trot_frame();
    rc_command_t out;

    printf("[3] 加速度限幅：1ms 内 vx 变化不超过 RC_ACC_VX*dt\n");
#if (RC_CH_VX == 0)
    printf("  (跳过：RC_CH_VX=0)\n");
#else
    rc_map_init();
    run_ms(&in, 10);
    set_raw(&in, RC_CH_VX, (uint16_t)RC_RAW_MAX);
    rc_map_update(&in, 0.001f, &out, 0);
    CHECK_NEAR(out.vx, dir_of(RC_DIR_VX) * RC_ACC_VX * 0.001f, 1e-6);
#endif
}

static void test_yaw_and_lateral(void)
{
    rc_input_t in = armed_trot_frame();
    rc_command_t out;
    float wmax = RC_WZ_MAX * expect_scale(RC_SPEED_HIGH);
    float vmax = RC_VY_MAX * expect_scale(RC_SPEED_HIGH);

    printf("[4] 右摇杆左右=转向、左摇杆左右=横移（方向随 RC_DIR_YAW/VY）\n");
#if (RC_CH_YAW != 0)
    rc_map_init();
    run_ms(&in, 10);
    set_raw(&in, RC_CH_YAW, (uint16_t)RC_RAW_MIN);   /* 左推 */
    out = run_ms(&in, 600);
    CHECK_NEAR(out.wz, -dir_of(RC_DIR_YAW) * wmax, 1e-3);

    in = armed_trot_frame();
    rc_map_init();
    run_ms(&in, 10);
    set_raw(&in, RC_CH_YAW, (uint16_t)RC_RAW_MAX);   /* 右推 */
    out = run_ms(&in, 600);
    CHECK_NEAR(out.wz, dir_of(RC_DIR_YAW) * wmax, 1e-3);
#else
    printf("  (跳过转向：RC_CH_YAW=0)\n");
#endif

#if (RC_CH_VY != 0)
    in = armed_trot_frame();
    rc_map_init();
    run_ms(&in, 10);
    set_raw(&in, RC_CH_VY, (uint16_t)RC_RAW_MIN);    /* 左推 */
    out = run_ms(&in, 400);
    CHECK_NEAR(out.vy, -dir_of(RC_DIR_VY) * vmax, 1e-3);

    in = armed_trot_frame();
    rc_map_init();
    run_ms(&in, 10);
    set_raw(&in, RC_CH_VY, (uint16_t)RC_RAW_MAX);    /* 右推 */
    out = run_ms(&in, 400);
    CHECK_NEAR(out.vy, dir_of(RC_DIR_VY) * vmax, 1e-3);
#else
    printf("  (跳过横移：RC_CH_VY=0)\n");
#endif
}

static void test_deadzone(void)
{
    rc_input_t in = armed_trot_frame();
    rc_command_t out;

    printf("[5] 死区：原始值偏离中位 10（< RC_RAW_DEADBAND）应无输出\n");
#if (RC_CH_VX == 0)
    printf("  (跳过：RC_CH_VX=0)\n");
#else
    rc_map_init();
    run_ms(&in, 10);
    set_raw(&in, RC_CH_VX, (uint16_t)(RC_RAW_MID + 10));
    out = run_ms(&in, 100);
    CHECK_NEAR(out.vx, 0.0f, 1e-6);

    /* 轻微超出死区应产生小速度，但远小于满速 */
    set_raw(&in, RC_CH_VX, (uint16_t)(RC_RAW_MID + 200));
    out = run_ms(&in, 100);
    CHECK(out.vx * dir_of(RC_DIR_VX) > 0.0f);
    CHECK(fabs(out.vx) < RC_VX_MAX * 0.5f);
#endif
}

static void test_arm_gate(void)
{
    rc_input_t in;
    rc_command_t out;

    printf("[6] 使能门控：急停开关在下 → 未使能、DAMP、速度为 0\n");
    in = make_frame((uint16_t)RC_RAW_MAX, (uint16_t)RC_RAW_MAX,
                    (uint16_t)RC_RAW_MIN, (uint16_t)RC_RAW_MIN);
    set_raw(&in, RC_CH_VX, (uint16_t)RC_RAW_MAX);
    rc_map_init();
    out = run_ms(&in, 100);
    CHECK(out.armed == 0U);
    CHECK(out.estop == 1U);
    CHECK(out.gait == RC_GAIT_DAMP);
    CHECK_NEAR(out.vx, 0.0f, 1e-6);

    printf("[7] 使能门控：上电时摇杆压住 → 不使能；回中后才使能\n");
    in = armed_trot_frame();
    set_raw(&in, any_motion_ch(), (uint16_t)RC_RAW_MAX);
    rc_map_init();
    out = run_ms(&in, 100);
    CHECK(out.armed == 0U);
    set_raw(&in, any_motion_ch(), (uint16_t)RC_RAW_MID);
    out = run_ms(&in, 10);
    CHECK(out.armed == 1U);
}

static void test_link_loss_and_bad_frame(void)
{
    rc_input_t in = armed_trot_frame();
    rc_command_t out;

    printf("[8] 失联：立即 DAMP/归零；恢复后必须把急停开关拨下再拨上才能重新使能\n");
    rc_map_init();
    run_ms(&in, 10);
#if (RC_CH_VX != 0)
    set_raw(&in, RC_CH_VX, (uint16_t)RC_RAW_MAX);
    out = run_ms(&in, 400);
    CHECK(fabs(out.vx) > RC_VX_MAX * 0.3f);
#else
    (void)in;
    out = run_ms(&in, 400);
#endif

    in.online = 0;
    rc_map_update(&in, 0.001f, &out, 0);
    CHECK(out.estop == 1U);
    CHECK(out.gait == RC_GAIT_DAMP);
    CHECK_NEAR(out.vx, 0.0f, 1e-6);
    CHECK(out.online == 0U);

    /* 恢复在线，但开关仍压在上：不允许自动恢复使能 */
    in.online = 1;
    set_raw(&in, RC_CH_VX, (uint16_t)RC_RAW_MID);
    out = run_ms(&in, 50);
    CHECK(out.armed == 0U);
    CHECK(out.estop == 1U);

    /* 拨下 → 拨上（摇杆已回中）→ 重新使能 */
    set_raw(&in, RC_SW_ARM, (uint16_t)RC_RAW_MIN);
    run_ms(&in, 5);
    set_raw(&in, RC_SW_ARM, (uint16_t)RC_RAW_MAX);
    out = run_ms(&in, 5);
    CHECK(out.armed == 1U);
    CHECK(out.estop == 0U);

    printf("[9] 坏帧：valid=0（状态字节报 LOST/FAILSAFE）同样立即急停\n");
    in = armed_trot_frame();
    rc_map_init();
    run_ms(&in, 10);
    in.valid = 0;
    rc_map_update(&in, 0.001f, &out, 0);
    CHECK(out.estop == 1U);
    CHECK(out.gait == RC_GAIT_DAMP);
    CHECK_NEAR(out.vx, 0.0f, 1e-6);
    CHECK(out.online == 0U);          /* 坏帧时 online 输出也应为 0 */
}

static void test_modes(void)
{
    rc_input_t in;
    rc_command_t out;

    printf("[10] 模式开关：上=TROT / 中=STAND / 下=DAMP（两段时只有上/下）\n");
    in = armed_trot_frame();
    rc_map_init();
    out = run_ms(&in, 10);
    CHECK(out.gait == RC_GAIT_TROT);

#if (RC_SW_MODE_POS == 3)
    set_raw(&in, RC_SW_MODE, (uint16_t)RC_RAW_MID);
    out = run_ms(&in, 10);
    CHECK(out.gait == RC_GAIT_STAND);
#endif

    printf("[11] DAMP 立即停车：运动中拨 SWA=下，输出速度当周期归零\n");
    in = armed_trot_frame();
    rc_map_init();
    run_ms(&in, 10);
#if (RC_CH_VX != 0)
    set_raw(&in, RC_CH_VX, (uint16_t)RC_RAW_MAX);
    out = run_ms(&in, 400);
    CHECK(fabs(out.vx) > RC_VX_MAX * 0.3f);
#else
    out = run_ms(&in, 400);
#endif
    set_raw(&in, RC_SW_MODE, (uint16_t)RC_RAW_MIN);   /* DAMP */
    rc_map_update(&in, 0.001f, &out, 0);
    CHECK(out.gait == RC_GAIT_DAMP);
    CHECK_NEAR(out.vx, 0.0f, 1e-6);
    CHECK_NEAR(out.height, 0.0f, 1e-6);
}

static void test_height(void)
{
    rc_input_t in;
    rc_command_t out;

    printf("[12] 机身高度：由高度杆映射，且做速率限幅；DAMP 时输出 0(无效)\n");
    in = armed_trot_frame();
#if (RC_SW_MODE_POS == 3)
    set_raw(&in, RC_SW_MODE, (uint16_t)RC_RAW_MID);   /* STAND 模式 */
#endif
    rc_map_init();
    out = run_ms(&in, 10);
#if (RC_CH_HEIGHT == 0)
    /* 高度通道被关闭：height 恒为 0（无效） */
    CHECK_NEAR(out.height, 0.0f, 1e-6);
    (void)in;
#elif (RC_SW_MODE_POS == 3) && (RC_HEIGHT_IN_STAND != 0)
    CHECK_NEAR(out.height, (RC_HEIGHT_MIN + RC_HEIGHT_MAX) * 0.5f, 1e-4);

    set_raw(&in, RC_CH_HEIGHT,
            (uint16_t)((RC_DIR_HEIGHT > 0) ? RC_RAW_MAX : RC_RAW_MIN));
    rc_map_update(&in, 0.001f, &out, 0);
    CHECK(out.height < RC_HEIGHT_MAX - 1e-4f);        /* 一个周期不可能到顶 */
    out = run_ms(&in, 600);
    CHECK_NEAR(out.height, RC_HEIGHT_MAX, 1e-4);
#else
    /* 两段模式开关（或 STAND 关闭高度）时，按实际步态判断：
     * TROT 下高度有效（中位杆 → 中位高度），STAND/DAMP 下高度输出 0 */
    if (out.gait == RC_GAIT_TROT) {
        CHECK_NEAR(out.height, (RC_HEIGHT_MIN + RC_HEIGHT_MAX) * 0.5f, 1e-4);
    } else {
        CHECK_NEAR(out.height, 0.0f, 1e-6);
    }
#endif

    /* DAMP 时 height 必须为 0 */
    in = armed_trot_frame();
    set_raw(&in, RC_SW_MODE, (uint16_t)RC_RAW_MIN);
    rc_map_init();
    out = run_ms(&in, 10);
    CHECK_NEAR(out.height, 0.0f, 1e-6);
}

static void test_jump(void)
{
    rc_input_t in = armed_trot_frame();
    rc_command_t out;

    printf("[13] 跳跃：只在开关上升沿触发一次，且只在 TROT + 已使能时\n");
    rc_map_init();
    out = run_ms(&in, 10);
    CHECK(out.jump == 0U);

    set_raw(&in, RC_SW_JUMP, (uint16_t)RC_RAW_MAX);
    rc_map_update(&in, 0.001f, &out, 0);
    CHECK(out.jump == 1U);

    out = run_ms(&in, 100);
    CHECK(out.jump == 0U);

    /* 冷却期内拨下再拨上 → 不触发 */
    set_raw(&in, RC_SW_JUMP, (uint16_t)RC_RAW_MIN);
    run_ms(&in, 10);
    set_raw(&in, RC_SW_JUMP, (uint16_t)RC_RAW_MAX);
    out = run_ms(&in, 10);
    CHECK(out.jump == 0U);

    /* 冷却结束 → 可再次触发 */
    set_raw(&in, RC_SW_JUMP, (uint16_t)RC_RAW_MIN);
    run_ms(&in, (int)RC_JUMP_COOLDOWN_MS + 20);
    set_raw(&in, RC_SW_JUMP, (uint16_t)RC_RAW_MAX);
    rc_map_update(&in, 0.001f, &out, 0);
    CHECK(out.jump == 1U);

    printf("[14] 跳跃互锁：STAND/DAMP/未使能时拨跳跃开关不触发\n");
    in = armed_trot_frame();
    set_raw(&in, RC_SW_MODE, (uint16_t)RC_RAW_MIN);   /* DAMP */
    rc_map_init();
    run_ms(&in, 10);
    set_raw(&in, RC_SW_JUMP, (uint16_t)RC_RAW_MAX);
    out = run_ms(&in, 10);
    CHECK(out.jump == 0U);

    printf("[15] 首帧保护：上电时跳跃开关已经在上，不触发\n");
    in = armed_trot_frame();
    set_raw(&in, RC_SW_JUMP, (uint16_t)RC_RAW_MAX);
    rc_map_init();
    out = run_ms(&in, 10);
    CHECK(out.jump == 0U);
}

static void test_speed_switch(void)
{
    rc_input_t in = armed_trot_frame();
    rc_command_t out;

    printf("[16] 速度档：下=35%% / 中=65%% / 上=100%%（再乘旋钮，若启用）\n");
    rc_map_init();
    run_ms(&in, 10);
    set_raw(&in, RC_CH_VX, (uint16_t)RC_RAW_MAX);

    set_raw(&in, RC_SW_SPEED, (uint16_t)RC_RAW_MIN);
    out = run_ms(&in, 600);
    CHECK_NEAR(out.speed_scale, expect_scale(RC_SPEED_LOW), 1e-6);
#if (RC_CH_VX != 0)
    CHECK_NEAR(out.vx, dir_of(RC_DIR_VX) * RC_VX_MAX * expect_scale(RC_SPEED_LOW), 1e-3);
#endif

#if (RC_SW_SPEED_POS == 3)
    set_raw(&in, RC_SW_SPEED, (uint16_t)RC_RAW_MID);
    out = run_ms(&in, 600);
    CHECK_NEAR(out.speed_scale, expect_scale(RC_SPEED_MID), 1e-6);
#endif

    set_raw(&in, RC_SW_SPEED, (uint16_t)RC_RAW_MAX);
    out = run_ms(&in, 600);
    CHECK_NEAR(out.speed_scale, expect_scale(RC_SPEED_HIGH), 1e-6);
}

static void test_arm_failsafe_decode(void)
{
    rc_input_t in = armed_trot_frame();
    rc_command_t out;

    printf("[17] 急停 fail-safe：SWD 拨到中位(992)必须立即 DISARMED（防三段开关误判）\n");
    rc_map_init();
    out = run_ms(&in, 10);
    CHECK(out.armed == 1U);

    set_raw(&in, RC_SW_ARM, (uint16_t)RC_RAW_MID);    /* 假设 SWD 实际是三段，拨到中位 */
    rc_map_update(&in, 0.001f, &out, 0);
    CHECK(out.armed == 0U);
    CHECK(out.estop == 1U);
    CHECK(out.gait == RC_GAIT_DAMP);
}

static void test_bad_args_and_dt(void)
{
    rc_input_t in = armed_trot_frame();
    rc_command_t out;
    rc_map_debug_t dbg;

    printf("[18] 参数/边界：NULL 返回 -1；dt 异常回退 1ms；raw 0/2047 不越界\n");
    rc_map_init();
    CHECK(rc_map_update(0, 0.001f, &out, 0) == -1);
    CHECK(rc_map_update(&in, 0.001f, 0, 0) == -1);

    /* dt = 0 / 负数 / 超大：都按 1ms 处理，不应产生 NaN/巨大值 */
    set_raw(&in, RC_CH_VX, (uint16_t)RC_RAW_MAX);
    rc_map_update(&in, 0.0f, &out, &dbg);
    CHECK(out.vx == out.vx);                 /* NaN 自比较为 false */
    CHECK(out.vx <= RC_VX_MAX * 1.01f);
    rc_map_update(&in, -1.0f, &out, &dbg);
    CHECK(out.vx == out.vx);
    rc_map_update(&in, 10.0f, &out, &dbg);
    CHECK(out.vx == out.vx);

    /* raw 越界也要被钳到 ±1 */
    in = armed_trot_frame();
    rc_map_init();
    run_ms(&in, 10);
    set_raw(&in, RC_CH_VX, 0);
    out = run_ms(&in, 800);
    CHECK(out.vx >= -RC_VX_MAX * 1.01f);
    set_raw(&in, RC_CH_VX, 2047);
    out = run_ms(&in, 800);
    CHECK(out.vx <= RC_VX_MAX * 1.01f);
}

static void test_debug_output(void)
{
    rc_input_t in = armed_trot_frame();
    rc_command_t out;
    rc_map_debug_t dbg;

    printf("[19] 调试输出：通道归一化值与开关档位\n");
    rc_map_init();
    set_raw(&in, RC_CH_VX, (uint16_t)RC_RAW_MAX);
    set_raw(&in, RC_SW_MODE, (uint16_t)RC_RAW_MIN);
    memset(&dbg, 0, sizeof(dbg));
    rc_map_update(&in, 0.001f, &out, &dbg);
    CHECK(dbg.sw_mode == -1);
    CHECK(dbg.sw_arm == 1);
#if (RC_CH_VX != 0)
    CHECK_NEAR(dbg.stick[0], dir_of(RC_DIR_VX), 1e-5);
#endif
}

int main(void)
{
    printf("==== rc_map 单元测试（读取当前 rc_map_config.h）====\n");
    printf("通道: VX=CH%d VY=CH%d YAW=CH%d HEIGHT=CH%d KNOB=CH%d\n",
           RC_CH_VX, RC_CH_VY, RC_CH_YAW, RC_CH_HEIGHT, RC_CH_SPEED_KNOB);
    printf("开关: MODE=CH%d(%d段) SPEED=CH%d(%d段) JUMP=CH%d(%d段) ARM=CH%d(%d段)\n",
           RC_SW_MODE, RC_SW_MODE_POS, RC_SW_SPEED, RC_SW_SPEED_POS,
           RC_SW_JUMP, RC_SW_JUMP_POS, RC_SW_ARM, RC_SW_ARM_POS);
    printf("RAW_MIN/MID/MAX=%d/%d/%d deadzone=%.3f VX_MAX=%.2f WZ_MAX=%.2f\n\n",
           RC_RAW_MIN, RC_RAW_MID, RC_RAW_MAX, (double)RC_STICK_DEADZONE,
           (double)RC_VX_MAX, (double)RC_WZ_MAX);

    test_neutral();
    test_forward_backward();
    test_slew_limit();
    test_yaw_and_lateral();
    test_deadzone();
    test_arm_gate();
    test_link_loss_and_bad_frame();
    test_modes();
    test_height();
    test_jump();
    test_speed_switch();
    test_arm_failsafe_decode();
    test_bad_args_and_dt();
    test_debug_output();

    printf("\n==== 结果：%d passed, %d failed ====\n", g_pass, g_fail);
    return (g_fail == 0) ? 0 : 1;
}
