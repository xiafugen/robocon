# -*- coding: utf-8 -*-
"""生成《遥控器映射表》xlsx + csv（与 rc_map_config.h / docs 一致）。
用法：python tools/gen_mapping_table.py
"""
import csv
import os
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DOCS = os.path.join(ROOT, 'docs')
os.makedirs(DOCS, exist_ok=True)

TITLE_FILL = PatternFill('solid', fgColor='1F4E79')
HEAD_FILL = PatternFill('solid', fgColor='2E75B6')
ZEBRA_FILL = PatternFill('solid', fgColor='EAF1F8')
TITLE_FONT = Font(name='微软雅黑', size=14, bold=True, color='FFFFFF')
HEAD_FONT = Font(name='微软雅黑', size=11, bold=True, color='FFFFFF')
BODY_FONT = Font(name='微软雅黑', size=10)
THIN = Side(style='thin', color='B7C9DB')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

# ---------------- 数据 ----------------
ch_rows = [
    ['右摇杆 左右', 'CH1', 'raw[0]', '192 ~ 1792', '992', '连续/回中', '左转 / 右转（左右拐）', 'wz (rad/s)', '右推 = 右转(-)', '宇树 Go2: 右摇杆左右=转向'],
    ['右摇杆 上下', 'CH2', 'raw[1]', '192 ~ 1792', '992', '连续/回中', '前进 / 后退', 'vx (m/s)', '上推 = 前进(+)', '自动回中杆：松手即停，最安全'],
    ['左摇杆 上下(油门)', 'CH3', 'raw[2]', '192 ~ 1792', '992', '连续/不回中', '机身升高 / 降低', 'height (m)', '上推 = 升高(+)', '油门杆通常不回中，做高度保持；可设 RC_CH_HEIGHT=0 关闭'],
    ['左摇杆 左右', 'CH4', 'raw[3]', '192 ~ 1792', '992', '连续/回中', '左移 / 右移（可选）', 'vy (m/s)', '左推 = 左移(+)', '宇树 Go2: 左摇杆左右=平移'],
    ['拨杆 SWA', 'CH5', 'raw[4]', '离散', '—', '开关', '模式 / 步态', 'gait', '—', '默认假设三段，见"开关映射"'],
    ['拨杆 SWB', 'CH6', 'raw[5]', '离散', '—', '开关', '速度档位', 'speed_scale', '—', '默认假设三段'],
    ['拨杆 SWC', 'CH7', 'raw[6]', '离散', '—', '开关', '跳跃触发', 'jump', '—', '上升沿触发一次'],
    ['拨杆 SWD', 'CH8', 'raw[7]', '离散', '—', '开关', '使能 / 急停', 'armed / estop', '—', 'fail-safe：只有明确在上档才使能'],
    ['旋钮 VRA', 'CH9', 'raw[8]', '连续', '—', '旋钮', '（预留）速度微调', 'speed_scale', '—', '默认关闭（RC_CH_SPEED_KNOB=0）'],
    ['旋钮 VRB', 'CH10', 'raw[9]', '连续', '—', '旋钮', '（预留）', '—', '—', '未使用'],
]

sw_rows = [
    ['SWA', 'CH5', '三段（默认假设）', 'TROT 小跑', 'STAND 站立', 'DAMP 阻尼趴下', '模式 / 步态', '若实为两段：上=TROT、下=DAMP（STAND 不可达，小跑原地即站立）'],
    ['SWB', 'CH6', '三段（默认假设）', '快 100%', '中 65%', '慢 35%', '速度档位', '若实为两段：上=100%、下=35%'],
    ['SWC', 'CH7', '两段（默认假设）', '触发一次跳跃', '待命', '待命', '跳跃', '上升沿触发；保持在上不会连续跳；1s 冷却；仅 ARMED+TROT 生效'],
    ['SWD', 'CH8', '两段（默认假设）', 'ARMED 使能', 'DISARMED', 'DISARMED', '使能 / 急停', 'fail-safe：中位/下档一律急停；失联后必须拨下再拨上；建议用两段开关'],
]

action_rows = [
    ['前进', '右摇杆 CH2 上推', 'vx > 0', '最大 0.6 m/s（RC_VX_MAX）', '需 SWD 在上 + 三根运动摇杆回中 + SWA=TROT'],
    ['后退', '右摇杆 CH2 下拉', 'vx < 0', '最大 -0.6 m/s', '同上'],
    ['左拐', '右摇杆 CH1 左推', 'wz > 0', '最大 1.2 rad/s', '同上，可原地转'],
    ['右拐', '右摇杆 CH1 右推', 'wz < 0', '最大 -1.2 rad/s', '同上'],
    ['左移 / 右移', '左摇杆 CH4 左右推', 'vy', '最大 ±0.4 m/s', '可选；不接横移就把 RC_CH_VY 设为 0'],
    ['升高 / 降低', '左摇杆 CH3 上下推', 'height', '0.18 ~ 0.32 m', '油门杆不回中 = 高度保持；DAMP 时输出 0（无效）'],
    ['切小跑', 'SWA 拨上', 'gait = RC_GAIT_TROT', '—', '已使能时生效'],
    ['站立', 'SWA 拨中', 'gait = RC_GAIT_STAND', '—', '只调高度，速度平滑降到 0'],
    ['趴下 / 阻尼', 'SWA 拨下', 'gait = RC_GAIT_DAMP', '—', '速度当周期立即清零'],
    ['跳一次', 'SWC 拨上（上升沿）', 'jump = 1（单周期）', '—', '需 ARMED + TROT + 冷却结束；上电已在上不触发'],
    ['减速档', 'SWB 拨下', 'speed_scale = 0.35', '—', '乘到步频/步长'],
    ['急停', 'SWD 拨下 / 中位', 'estop = 1, gait = DAMP', '—', '速度立即清零；重新使能需拨下再拨上 + 摇杆回中'],
]

param_rows = [
    ['RC_CH_VX / VY / YAW / HEIGHT', '2 / 4 / 1 / 3', '通道', '右手驾驶 + 左手辅助（见文档 0.2）', '宇树原版布局：VX=3、HEIGHT=2'],
    ['RC_RAW_MIN / MID / MAX', '192 / 992 / 1792', 'raw', '10通SBUS协议.pdf 公式 + 说明书 1500us 中位', '必测；实测值覆盖'],
    ['RC_RAW_DEADBAND', '20', 'raw', '—', '一般不用改（会被 STICK_DEADZONE 覆盖）'],
    ['RC_STICK_DEADZONE', '0.05', '归一化', 'MIT 0.075~0.1；D1 0.013', '手放开狗不动即可'],
    ['RC_STICK_EXPO', '0.0', '—', '—', '想中位细腻改 0.2~0.35'],
    ['RC_VX_MAX', '0.6', 'm/s', 'MIT 3.0 / D1 3.0（上限参考）', '从 0.3 起，实机逐步加'],
    ['RC_VY_MAX', '0.4', 'm/s', 'MIT 2.0', '不用横移设 0'],
    ['RC_WZ_MAX', '1.2', 'rad/s', 'MIT 2.5 / D1 6.0', '先 1.0~1.5 防侧翻'],
    ['RC_HEIGHT_MIN / MAX', '0.18 / 0.32', 'm', 'MIT 站立高度 0.26 m', '按腿长标定'],
    ['RC_ACC_VX / VY / WZ', '2.5 / 2.5 / 8.0', 'm/s^2, rad/s^2', '—', '抖动/打滑就减小'],
    ['RC_ACC_HEIGHT', '0.20', 'm/s', '—', '高度变化太快会失稳'],
    ['RC_SPEED_LOW / MID / HIGH', '0.35 / 0.65 / 1.0', '—', 'D1 speed_ratio=[0.33,0.66,1.0]', '照抄即可'],
    ['RC_ARM_STICK_LIMIT', '0.10', '归一化', '—', '防上电弹射（只查三根运动杆）'],
    ['RC_JUMP_COOLDOWN_MS', '1000', 'ms', '—', '按跳跃动作时长调'],
    ['RC_SW_LOW_TH / HIGH_TH', '592 / 1392', 'raw', '192/992/1792 相邻档中点', '实测量后微调'],
    ['RC_SW_HYST', '40', 'raw', '—', '开关阈值附近抖动就加大'],
]

calib_rows = [
    ['CH1 右摇杆左右', '', '', '', '', '', ''],
    ['CH2 右摇杆上下', '', '', '', '', '', ''],
    ['CH3 左摇杆上下(油门)', '', '', '', '', '', ''],
    ['CH4 左摇杆左右', '', '', '', '', '', ''],
    ['SWA CH5', '', '', '', '', '', ''],
    ['SWB CH6', '', '', '', '', '', ''],
    ['SWC CH7', '', '', '', '', '', ''],
    ['SWD CH8', '', '', '', '', '', ''],
    ['VRA CH9', '', '', '', '', '', ''],
    ['VRB CH10', '', '', '', '', '', ''],
]

wb = Workbook()


def write_sheet(ws, title, headers, rows, widths, note=None):
    ncol = len(headers)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncol)
    c = ws.cell(row=1, column=1, value=title)
    c.fill = TITLE_FILL
    c.font = TITLE_FONT
    c.alignment = Alignment(horizontal='center', vertical='center')
    ws.row_dimensions[1].height = 30

    for j, h in enumerate(headers, 1):
        cell = ws.cell(row=2, column=j, value=h)
        cell.fill = HEAD_FILL
        cell.font = HEAD_FONT
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = BORDER
    ws.row_dimensions[2].height = 24

    for i, row in enumerate(rows, 3):
        for j, val in enumerate(row, 1):
            cell = ws.cell(row=i, column=j, value=val)
            cell.font = BODY_FONT
            cell.border = BORDER
            cell.alignment = Alignment(vertical='center', wrap_text=True,
                                       horizontal='center' if j <= 2 else 'left')
            if i % 2 == 0:
                cell.fill = ZEBRA_FILL
        ws.row_dimensions[i].height = 26

    for j, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(j)].width = w

    if note:
        r = len(rows) + 4
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncol)
        c = ws.cell(row=r, column=1, value=note)
        c.font = Font(name='微软雅黑', size=9, italic=True, color='7F7F7F')
        c.alignment = Alignment(wrap_text=True, vertical='top')

    ws.freeze_panes = 'A3'


# Sheet1 摇杆/通道
ws = wb.active
ws.title = '1-通道分配'
write_sheet(ws, 'HT-10A 通道分配（出厂默认，Mode 2 左手油门）',
            ['物理控件', '通道', '程序索引', '原始值范围', '中位', '类型', '狗的动作', '输出字段', '正方向', '备注'],
            ch_rows, [16, 8, 10, 16, 8, 13, 26, 14, 18, 44])

# Sheet2 开关
ws = wb.create_sheet('2-开关映射')
write_sheet(ws, '四个拨杆开关映射（HT-10A: 一对两段 + 一对三段，具体哪对需实测）',
            ['开关', '通道', '默认假设段数', '上档', '中档', '下档', '功能', '安全说明 / 降级'],
            sw_rows, [10, 8, 16, 18, 14, 18, 16, 58])

# Sheet3 动作
ws = wb.create_sheet('3-动作指令')
write_sheet(ws, '用户动作 → 操作 → 指令字段',
            ['动作', '操作', '指令字段取值', '量程/示例', '安全条件'],
            action_rows, [16, 22, 30, 30, 48])

# Sheet4 参数
ws = wb.create_sheet('4-参数表')
write_sheet(ws, '可调参数（均在 include/rc_map_config.h）',
            ['参数', '默认值', '单位', '依据/参考', '调整建议'],
            param_rows, [32, 22, 18, 42, 34])

# Sheet5 标定记录
ws = wb.create_sheet('5-实机标定记录')
write_sheet(ws, '实机标定记录（上电后填写，回填 rc_map_config.h）',
            ['通道/开关', '最下/下档 raw', '中位/中档 raw', '最上/上档 raw', '实测段数(2/3)', '方向是否正确', '备注'],
            calib_rows, [24, 18, 18, 18, 16, 16, 40])

xlsx_path = os.path.join(DOCS, '遥控器映射表.xlsx')
wb.save(xlsx_path)

# ---------------- CSV（主映射简版，UTF-8 BOM 便于 Excel 直接打开） ----------------
csv_path = os.path.join(DOCS, '遥控器映射表.csv')
with open(csv_path, 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.writer(f)
    w.writerow(['物理控件', '通道', '狗的动作', '输出字段', '正方向', '说明'])
    for r in ch_rows:
        w.writerow([r[0], r[1], r[6], r[7], r[8], r[9]])
    w.writerow([])
    w.writerow(['开关', '通道', '功能', '上档', '中档', '下档', '安全说明'])
    for r in sw_rows:
        w.writerow([r[0], r[1], r[6], r[3], r[4], r[5], r[7]])

print('OK:', xlsx_path)
print('OK:', csv_path)
