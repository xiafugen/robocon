/*
 * rc_map.h — 遥控器(SBUS) → 机械狗运动指令 映射层
 * ==========================================================================
 * 设计目标
 *   1) 纯 C99、零 HAL / 零动态内存，可直接放进 STM32 工程（Keil / GCC 均可）；
 *   2) 输入只认"已经解好的原始通道值"(0~2047)，不碰串口/中断；
 *      因此可以在 PC 上用录制的帧做单元测试（见 tests/test_rc_map.c）；
 *   3) 输出是"语义化运动指令"(vx/vy/wz/height/gait/jump)，不直接写电机；
 *      由上层状态机/步态控制器决定怎么变成关节力矩。
 *
 * 数据流（对应 Robocon_Dog 工程）
 *   UART5 中断 → bsp_sbus.c → rc_ch1..rc_ch10 (0~2047)
 *        ↓ 本层（1ms 或 100Hz 调一次）
 *   rc_map_update() → rc_command_t {vx, vy, wz, height, gait, jump, estop}
 *        ↓ 上层（你的步态/FSM 代码）
 *   电机目标 / 关节力矩
 *
 * 典型用法（Robocon_Dog 的 1ms 任务里）：
 *
 *     #include "rc_map.h"
 *
 *     static rc_command_t g_cmd;
 *
 *     void task_1ms(void) {
 *         rc_input_t in;
 *         rc_map_fill_from_sbus(&in);      // 见 examples/rc_map_glue_robocon_dog.c
 *         rc_map_update(&in, 0.001f, &g_cmd);
 *     }
 *
 *     // 其它地方读 g_cmd.vx / g_cmd.gait / g_cmd.jump ...
 *
 * 安全规则（本层已实现，不要绕过）
 *   - 遥控失联 / 帧异常 / 开关未使能 → 立即输出 0 速度 + DAMP 步态，estop=1；
 *   - 使能必须"开关拨上 + 三根运动摇杆回中"同时满足，防止上电弹射；
 *   - 急停开关按 fail-safe 解码：只有明确在上档才 ARMED，中位/下档一律 DISARMED；
 *   - 失联后即使链路恢复，也必须把急停开关拨下再拨上，才允许重新使能；
 *   - 跳跃只在"已使能 + 小跑步态 + 上升沿 + 冷却结束"时触发一次；
 *   - vx/vy/wz 经加速度限幅，height 经速率限幅；急停/SWA=DAMP 时速度立即归零，
 *     STAND 模式才做平滑减速。
 */
#ifndef RC_MAP_H
#define RC_MAP_H

#include <stdint.h>
#include "rc_map_config.h"

#ifdef __cplusplus
extern "C" {
#endif

/* 遥控器通道数（HT-10A 为 10；SBUS 帧内是 16，这里只取前 10） */
#define RC_MAP_CH_NUM   10

/* --------------------------------------------------------------------------
 * 输入：一帧遥控数据
 * -------------------------------------------------------------------------- */
typedef struct
{
    /* raw[0] 对应 CH1，raw[9] 对应 CH10；数值 0~2047（SBUS 11bit 原值） */
    uint16_t raw[RC_MAP_CH_NUM];

    /* 1 = 本帧是正常帧（SBUS 状态字节没有 LOST/FAILSAFE 标志）
       0 = 本帧异常，本层会按失联处理 */
    uint8_t  valid;

    /* 1 = 链路在线（最近 100ms 收到过正常帧，如 SBUS_IsOnline()）
       0 = 失联，本层会立即进入急停/阻尼 */
    uint8_t  online;
} rc_input_t;

/* --------------------------------------------------------------------------
 * 输出：语义化运动指令
 * -------------------------------------------------------------------------- */
typedef enum
{
    RC_GAIT_DAMP  = 0,   /* 阻尼/趴下：输出无力矩，最安全 */
    RC_GAIT_STAND = 1,   /* 站立锁定：只调高度，不走动 */
    RC_GAIT_TROT  = 2    /* 小跑：可前后/横移/转向 */
} rc_gait_t;

typedef struct
{
    /* ---- 连续量（已做死区、方向、限幅、加速度/速率限制） ---- */
    float vx;             /* m/s   前进(+)/后退(-) */
    float vy;             /* m/s   左移(+)/右移(-) */
    float wz;             /* rad/s 左转(+)/右转(-) */
    float height;         /* m     目标机身高度；0 = 无效（DAMP/急停/未配置高度时） */

    /* ---- 离散状态 ---- */
    rc_gait_t gait;       /* 当前步态 */
    float    speed_scale; /* 速度比例 0~1（档位 × 旋钮），上层乘到步频/步长上 */
    uint8_t  armed;       /* 1 = 已使能（急停开关在上 + 摇杆回中过） */
    uint8_t  jump;        /* 1 = 本控制周期触发一次跳跃（只会是单周期脉冲） */
    uint8_t  estop;       /* 1 = 急停/失联；停车条件 = estop || (gait == RC_GAIT_DAMP) */
    uint8_t  online;      /* 1 = 链路在线且本帧正常（= in->online && in->valid） */
} rc_command_t;

/* --------------------------------------------------------------------------
 * 调试/标定用的中间量（可选，rc_map_update 的 dbg 传 NULL 即可）
 * -------------------------------------------------------------------------- */
typedef struct
{
    float stick[4];       /* [0]=vx [1]=vy [2]=wz [3]=height，归一化 -1~+1 */
    int8_t sw_mode;       /* -1=下 0=中 +1=上 */
    int8_t sw_speed;
    int8_t sw_jump;
    int8_t sw_arm;
    float knob;           /* 速度旋钮归一化 0~1（未接则为 1.0） */
} rc_map_debug_t;

/* --------------------------------------------------------------------------
 * API
 * -------------------------------------------------------------------------- */

/* 复位内部状态（上电 / 切模式时调用一次即可）。
 * 注意：复位后第一次 update 只记录开关初值，不会触发跳跃。 */
void rc_map_init(void);

/* 主映射函数。
 *   in  : 本周期遥控原始帧（不可为 NULL）
 *   dt  : 距上次调用的秒数，正常 0.001f (1kHz) 或 0.01f (100Hz)
 *   out : 输出指令（不可为 NULL）
 *   dbg : 可选调试输出，可为 NULL
 * 返回值：成功 0；in/out 为 NULL 返回 -1。
 */
int rc_map_update(const rc_input_t *in, float dt, rc_command_t *out, rc_map_debug_t *dbg);

/* 步态枚举转字符串（打印/OLED 调试用） */
const char *rc_gait_name(rc_gait_t gait);

#ifdef __cplusplus
}
#endif

#endif /* RC_MAP_H */
