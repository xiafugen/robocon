/*
 * rc_map_config.h — 遥控器 → 机械狗动作映射：硬件配置表（唯一需要按实物修改的文件）
 * ==========================================================================
 * 适用硬件：HOTRC HT-10A 十通道 2.4G 遥控器 + F-10A(SBUS) 接收机
 * 接收链路：接收机 SBUS → UART5(100000bps, 8E2, 25 字节帧) → bsp_sbus.c 解出
 *           rc_ch1..rc_ch10 原始值(0~2047)
 *
 * 本文件把 10 个物理通道"绑定"成 4 个连续量 + 4 个开关，并给出所有可调参数。
 * 写代码时只 include 本文件和 rc_map.h，不要直接写 3/5/7 这类魔法数字。
 *
 * 重要：HT-10A 出厂默认有"通道映射"菜单，CH5~CH10 可用菜单自由改绑开关。
 *       若实机改过"通道映射 / 通道正反 / 通道行程 / 微调"，先恢复出厂再核对本表。
 *
 * 所有可调宏都包在 #ifndef 里，可用编译器 -D 覆盖（做多套配置/CI 时方便）。
 * ==========================================================================
 */
#ifndef RC_MAP_CONFIG_H
#define RC_MAP_CONFIG_H

/* ==========================================================================
 * 一、摇杆通道分配（HT-10A 出厂默认，Mode 2 左手油门）
 * --------------------------------------------------------------------------
 * 物理通道（出厂默认）：
 *   CH1 = 右摇杆 左右        CH2 = 右摇杆 上下
 *   CH3 = 左摇杆 上下(油门)  CH4 = 左摇杆 左右
 *   CH5 = SWA   CH6 = SWB   CH7 = SWC   CH8 = SWD
 *   CH9 = VRA   CH10 = VRB
 *
 * ★ 关键硬件事实：Mode 2 的 CH3 是"油门"杆（说明书"3 通道默认 1000/1500"），
 *   航模遥控器的油门杆通常带棘轮、**松手不回中**；CH1/CH2/CH4 才是自动回中杆。
 *   所以默认把"驾驶"放在右摇杆（CH1/CH2，两个轴都自动回中）：
 *
 *     CH2 右摇杆上下 → vx      前进(+)/后退(-)      ← 松手自动回中 = 松手即停
 *     CH1 右摇杆左右 → wz      右转(-)/左转(+)      ← 松手自动回中
 *     CH4 左摇杆左右 → vy      左移(+)/右移(-)      ← 松手自动回中（可选）
 *     CH3 左摇杆上下 → height  机身高度             ← 油门杆，不回中，做"高度保持"
 *
 *   —— 这样"前进/后退/左右拐"三个动作全在自动回中的杆上，松手必停，最安全。
 *
 * 如果你确认 CH3 会自动回中，或换成宇树手柄式布局，可改成：
 *     #define RC_CH_VX 3      // 左摇杆上下 = 前后
 *     #define RC_CH_HEIGHT 2  // 右摇杆上下 = 高度
 *   其余不变（vy=4, yaw=1）。两种布局代码都支持，只改这两个数字。
 *   ⚠️ 警告：只有**确认 CH3 会自动回中**才用这种布局。否则 vx 会落到不回中的油门杆上，
 *      松手不会自动停，必须靠 SWD 急停——不安全，不建议。
 *
 * 通道号必须是 0~10；填 0 表示"该功能不接摇杆"（输出恒为 0/中位）。
 * ========================================================================== */
#ifndef RC_CH_VX
#define RC_CH_VX            2   /* 前进/后退      CH2 右摇杆上下（自动回中） */
#endif
#ifndef RC_CH_VY
#define RC_CH_VY            4   /* 左右横移       CH4 左摇杆左右（自动回中） */
#endif
#ifndef RC_CH_YAW
#define RC_CH_YAW           1   /* 左右转(偏航)   CH1 右摇杆左右（自动回中） */
#endif
#ifndef RC_CH_HEIGHT
#define RC_CH_HEIGHT        3   /* 机身高度/俯仰  CH3 左摇杆上下（油门杆，不回中） */
#endif

/* CH9 VRA 旋钮 = 速度比例旋钮（RC_KNOB_MIN~1.0 倍）。
 * 默认 0 = 关闭（只用开关档位，手感最直观）。
 * 想用旋钮微调速度时改成 9 或 10（对应 VRA/VRB），并先按 docs 第 7 章标定 CH9/CH10。 */
#ifndef RC_CH_SPEED_KNOB
#define RC_CH_SPEED_KNOB    0
#endif

/* ==========================================================================
 * 二、四个拨杆开关分配
 * --------------------------------------------------------------------------
 * HT-10A 有 4 个拨杆：SWA(CH5) SWB(CH6) SWC(CH7) SWD(CH8)。
 * 官方资料只写"一对两段 + 一对三段"，**没写具体哪两个是三段**（本地说明书/产品图
 * 都无法确认）。所以默认按"SWA/SWB 三段、SWC/SWD 两段"配置，并用下面 4 个 *_POS
 * 宏声明每路实际段数；实机数一下档位再改，代码会自动降级（详见 docs 7.3）。
 *
 *   SWA CH5 模式/步态  上=小跑(TROT) 中=站立(STAND) 下=阻尼趴下(DAMP)
 *   SWB CH6 速度档     上=快(100%) 中=中(65%) 下=慢(35%)
 *   SWC CH7 跳跃触发   上=触发一次(上升沿) 下=待命
 *   SWD CH8 使能/急停  上=使能(ARMED) 其它=急停/未使能(DISARMED)
 *
 * ★ 急停开关的判定是"fail-safe"的：只有明确在上档才 ARMED，中位/下档/噪声一律
 *   DISARMED（即使 SWD 实际是三段，拨到中位也会立即急停）。
 * ★ 跳跃必须是"上升沿触发"，不能是电平——否则开关一直拨在上面会连续跳。
 * ========================================================================== */
#ifndef RC_SW_MODE
#define RC_SW_MODE          5   /* SWA */
#endif
#ifndef RC_SW_SPEED
#define RC_SW_SPEED         6   /* SWB */
#endif
#ifndef RC_SW_JUMP
#define RC_SW_JUMP          7   /* SWC */
#endif
#ifndef RC_SW_ARM
#define RC_SW_ARM           8   /* SWD */
#endif

/* 每个开关的物理段数：2=两段自锁，3=三段自锁。请按实物实测修改！ */
#ifndef RC_SW_MODE_POS
#define RC_SW_MODE_POS      3
#endif
#ifndef RC_SW_SPEED_POS
#define RC_SW_SPEED_POS     3
#endif
#ifndef RC_SW_JUMP_POS
#define RC_SW_JUMP_POS      2
#endif
#ifndef RC_SW_ARM_POS
#define RC_SW_ARM_POS       2
#endif

/* ==========================================================================
 * 三、SBUS 原始值标定（★ 最容易错的地方，务必实测）
 * --------------------------------------------------------------------------
 * SBUS 名义 11bit：0~2047；但舵量 1000~2000us 对应的实际原始值一般是：
 *     1000us → 192     1500us(中位) → 992     2000us → 1792
 * 部分接收机输出标准 172~1811（中位 992）。而现有 bsp_sbus.c 归一化用了
 * 中位 1024，会带来约 +3% 的系统偏差——所以本模块不用 rc_chN_n，
 * 而是自己按下面这组值做归一化。上电后请按 docs 第 7 章实测并改写。
 *
 * 标定方法：遥控器摇杆全部回中，打印 rc_ch1..rc_ch4，
 *           稳定值就是 RC_RAW_MID；再各方向推到底得到 MIN/MAX。
 * ========================================================================== */
#ifndef RC_RAW_MIN
#define RC_RAW_MIN          192
#endif
#ifndef RC_RAW_MID
#define RC_RAW_MID          992
#endif
#ifndef RC_RAW_MAX
#define RC_RAW_MAX          1792
#endif

/* 摇杆机械中位死区（原始值）。注意它会被 RC_STICK_DEADZONE(0.05≈±40raw)
 * 完全覆盖；一般保持 20 即可，想用更小归一化死区时再降低它。 */
#ifndef RC_RAW_DEADBAND
#define RC_RAW_DEADBAND     20
#endif

/* ==========================================================================
 * 四、开关档位判定阈值（原始值）
 * --------------------------------------------------------------------------
 * 三段开关三个位置约为 1792 / 992 / 192；两段约为 1792 / 192。
 * 用区间判定，不做 == 精确比较：
 *     raw > RC_SW_HIGH_TH  → 上档
 *     raw < RC_SW_LOW_TH   → 下档
 *     其余                 → 中档
 * 阈值取相邻档位的中间值（592 / 1392），留足余量；RC_SW_HYST 为回差，
 * 防止开关停在阈值附近时状态抖动。
 * ========================================================================== */
#ifndef RC_SW_LOW_TH
#define RC_SW_LOW_TH        592
#endif
#ifndef RC_SW_HIGH_TH
#define RC_SW_HIGH_TH       1392
#endif
#ifndef RC_SW_HYST
#define RC_SW_HYST          40
#endif

/* ==========================================================================
 * 五、通道方向（推杆方向与数值正负的对应）
 * --------------------------------------------------------------------------
 * 默认假设：**摇杆向上推 / 向右推 → 原始值变大**（大多数遥控器的出厂正反）。
 * 已按此假设把方向定成：
 *     上推 = 前进(+vx)   右推 = 右转(-wz)   左推 = 左移(+vy)   上推 = 升高(+height)
 * 若实机方向相反（例如右推变左转），把对应 RC_DIR 改成 (-1)；
 * 也可以优先在遥控器菜单「通道正反」里改。测试方法见 docs 第 7.4 节。
 * ========================================================================== */
#ifndef RC_DIR_VX
#define RC_DIR_VX           (+1)   /* +1: 上推=前进 */
#endif
#ifndef RC_DIR_VY
#define RC_DIR_VY           (-1)   /* -1: 左推(原始值变小)=左移 */
#endif
#ifndef RC_DIR_YAW
#define RC_DIR_YAW          (-1)   /* -1: 右推(原始值变大)=右转(负角速度) */
#endif
#ifndef RC_DIR_HEIGHT
#define RC_DIR_HEIGHT       (+1)   /* +1: 上推=升高 */
#endif
#ifndef RC_DIR_SPEED_KNOB
#define RC_DIR_SPEED_KNOB   (+1)   /* +1: 旋钮顺时针=加速 */
#endif

/* ==========================================================================
 * 六、摇杆手感：死区 / 曲线 / 限幅
 * ========================================================================== */
/* 归一化死区：|x| < 该值直接置 0；超出后重新拉伸到 0~1（手感线性）
 * 参考：MIT Cheetah 用 0.075~0.1，D1 轮足用 0.013。比赛起步建议 0.05。 */
#ifndef RC_STICK_DEADZONE
#define RC_STICK_DEADZONE   0.05f
#endif

/* Expo 曲线：0=纯线性；0.2~0.35 中位更细腻，适合精细走位。 */
#ifndef RC_STICK_EXPO
#define RC_STICK_EXPO       0.0f
#endif

/* 最大速度/角速度（★ 实机从小往大调，先别用满） */
#ifndef RC_VX_MAX
#define RC_VX_MAX           0.60f   /* m/s   前后最大线速度 */
#endif
#ifndef RC_VY_MAX
#define RC_VY_MAX           0.40f   /* m/s   横移最大线速度 */
#endif
#ifndef RC_WZ_MAX
#define RC_WZ_MAX           1.20f   /* rad/s 最大偏航角速度(约 69°/s) */
#endif

/* 机身高度范围（米），由 CH3 映射；若狗没有高度控制就先忽略此输出 */
#ifndef RC_HEIGHT_MIN
#define RC_HEIGHT_MIN       0.18f
#endif
#ifndef RC_HEIGHT_MAX
#define RC_HEIGHT_MAX       0.32f
#endif

/* 加速度/速率限幅：防止指令突变把狗拽倒。
 * vx/vy/wz 用加速度(m/s^2、rad/s^2)；height 用速率(m/s)。 */
#ifndef RC_ACC_VX
#define RC_ACC_VX           2.5f
#endif
#ifndef RC_ACC_VY
#define RC_ACC_VY           2.5f
#endif
#ifndef RC_ACC_WZ
#define RC_ACC_WZ           8.0f
#endif
#ifndef RC_ACC_HEIGHT
#define RC_ACC_HEIGHT       0.20f
#endif

/* ==========================================================================
 * 七、速度档位 + 旋钮
 * ========================================================================== */
#ifndef RC_SPEED_LOW
#define RC_SPEED_LOW        0.35f   /* 慢档：最大速度的 35% */
#endif
#ifndef RC_SPEED_MID
#define RC_SPEED_MID        0.65f   /* 中档 */
#endif
#ifndef RC_SPEED_HIGH
#define RC_SPEED_HIGH       1.00f   /* 快档 */
#endif

/* VRA 旋钮：归一化 0~1 线性映射到 RC_KNOB_MIN~1.0，再与档位相乘 */
#ifndef RC_KNOB_MIN
#define RC_KNOB_MIN         0.40f
#endif

/* 最终速度比例上限（保护：档位 × 旋钮 也不会超过它） */
#ifndef RC_SPEED_SCALE_MAX
#define RC_SPEED_SCALE_MAX  1.00f
#endif

/* ==========================================================================
 * 八、状态机 / 安全参数
 * ========================================================================== */
/* 使能时要求"运动摇杆"回中：|归一化| 小于该值才允许从"未使能"切到"使能"，
 * 防止上电时摇杆被压住导致突然冲出。
 * 注意：只检查 vx/vy/wz 三根自动回中杆；高度杆(CH3 油门，不回中)不参与，
 *       否则用油门杆做高度时永远无法使能。 */
#ifndef RC_ARM_STICK_LIMIT
#define RC_ARM_STICK_LIMIT  0.10f
#endif

/* 跳跃冷却时间（ms）：两次跳跃之间的最小间隔 */
#ifndef RC_JUMP_COOLDOWN_MS
#define RC_JUMP_COOLDOWN_MS 1000U
#endif

/* 站立模式下是否允许用高度杆调高度（1=允许；0=STAND 时 height 输出 0=无效） */
#ifndef RC_HEIGHT_IN_STAND
#define RC_HEIGHT_IN_STAND  1
#endif

/* ==========================================================================
 * 九、编译期自检（防止配置写错后上机才炸）
 * ========================================================================== */
#if (RC_CH_VX < 0) || (RC_CH_VX > 10) || (RC_CH_VY < 0) || (RC_CH_VY > 10) || \
    (RC_CH_YAW < 0) || (RC_CH_YAW > 10) || (RC_CH_HEIGHT < 0) || (RC_CH_HEIGHT > 10) || \
    (RC_CH_SPEED_KNOB < 0) || (RC_CH_SPEED_KNOB > 10)
#error "RC_MAP_CONFIG: 通道号必须在 0~10（0=不接）"
#endif

#if (RC_CH_VX != 0) && ((RC_CH_VX == RC_CH_VY) || (RC_CH_VX == RC_CH_YAW) || (RC_CH_VX == RC_CH_HEIGHT))
#error "RC_MAP_CONFIG: 摇杆通道不能重复"
#endif
#if (RC_CH_VY != 0) && ((RC_CH_VY == RC_CH_YAW) || (RC_CH_VY == RC_CH_HEIGHT))
#error "RC_MAP_CONFIG: 摇杆通道不能重复"
#endif
#if (RC_CH_YAW != 0) && (RC_CH_YAW == RC_CH_HEIGHT)
#error "RC_MAP_CONFIG: 摇杆通道不能重复"
#endif

#if (RC_SW_MODE == RC_SW_SPEED) || (RC_SW_MODE == RC_SW_JUMP) || (RC_SW_MODE == RC_SW_ARM) || \
    (RC_SW_SPEED == RC_SW_JUMP) || (RC_SW_SPEED == RC_SW_ARM) || (RC_SW_JUMP == RC_SW_ARM)
#error "RC_MAP_CONFIG: 四个开关通道号不能重复"
#endif

#if (RC_SW_MODE < 1) || (RC_SW_MODE > 10) || (RC_SW_SPEED < 1) || (RC_SW_SPEED > 10) || \
    (RC_SW_JUMP < 1) || (RC_SW_JUMP > 10) || (RC_SW_ARM < 1) || (RC_SW_ARM > 10)
#error "RC_MAP_CONFIG: 开关通道号必须在 1~10"
#endif

#if (RC_SW_MODE_POS < 2) || (RC_SW_MODE_POS > 3) || (RC_SW_SPEED_POS < 2) || (RC_SW_SPEED_POS > 3) || \
    (RC_SW_JUMP_POS < 2) || (RC_SW_JUMP_POS > 3) || (RC_SW_ARM_POS < 2) || (RC_SW_ARM_POS > 3)
#error "RC_MAP_CONFIG: *_POS 只能是 2 或 3"
#endif

#if (RC_RAW_MIN >= RC_RAW_MID) || (RC_RAW_MID >= RC_RAW_MAX)
#error "RC_MAP_CONFIG: 必须满足 RC_RAW_MIN < RC_RAW_MID < RC_RAW_MAX"
#endif

#if (RC_SW_LOW_TH <= RC_RAW_MIN) || (RC_SW_HIGH_TH >= RC_RAW_MAX) || (RC_SW_LOW_TH >= RC_SW_HIGH_TH)
#error "RC_MAP_CONFIG: 开关阈值必须满足 RC_RAW_MIN < LOW_TH < HIGH_TH < RC_RAW_MAX"
#endif

/* 说明：浮点参数（死区/Expo/最大速度/加速度/高度范围）无法在 C 预处理里做比较，
 * 这部分由 rc_map.c 在运行时做安全钳位（见 rc_map_update 开头），
 * 并在 tests/test_rc_map.c 里做单元验证。 */

#endif /* RC_MAP_CONFIG_H */
